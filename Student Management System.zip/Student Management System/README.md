# Student Management System

A simple C++ Console-based project that provides:
-User Registration
-User Login 
-Exit functionality

This project is structured using industry-standard folder organnisation.

------------------------------

## Requirements

-Windows OS
-VS Code
-C++ Compiler(g++/MinGW)

-------------------------------

## How to Compile and Run 

Open VS Code terminal and run

------------------------------


